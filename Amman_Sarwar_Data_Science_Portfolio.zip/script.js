const projectDetails = {
  jobs: {
    kicker: "POWER BI · DATA VISUALIZATION",
    title: "Jobs Analytics Dashboard",
    summary: "A Power BI dashboard organized into Data Table, Overview, Salary Analysis, Job Levels & Experience, and Companies & Locations.",
    bullets: ["Explore job-related measures through multiple dashboard pages.", "Compare salary, experience, job levels, companies, and locations where supported by the dataset.", "Add a screenshot and a short explanation of the dataset and verified insights."],
    tags: ["Power BI", "Data Visualization", "Dashboard Design"],
    link: ""
  },
  pbs: {
    kicker: "POWER BI · STATISTICAL DATA",
    title: "PBS Fertilizer Statistics",
    summary: "A dashboard created during PBS internship work to explore fertilizer statistics by province and year.",
    bullets: ["Dataset fields shared so far: Year, Province, Potash, Nitrogen, and Phosphate.", "Use province-by-year visuals to compare recorded values.", "Add the exact dataset source, internship dates, screenshots, and verified findings before publishing."],
    tags: ["Power BI", "Statistical Data", "Trend Analysis"],
    link: ""
  },
  emotion: {
    kicker: "PYTHON · MACHINE LEARNING",
    title: "Voice Emotion Recognition",
    summary: "A CREMA-D audio emotion project with preprocessing, feature extraction, model comparison, and a Streamlit application.",
    bullets: ["Explored and preprocessed audio samples from CREMA-D.", "Extracted audio features including MFCC, Chroma, Mel Spectrogram, Spectral Contrast, and Tonnetz during model development.", "Compared Logistic Regression, KNN, Decision Tree, Random Forest, SVM, and Gradient Boosting; Gradient Boosting was selected as the final model.", "Built a Streamlit app using extracted audio features. Add verified performance metrics and a demo link only if you want to share them."],
    tags: ["Python", "librosa", "scikit-learn", "Streamlit", "CREMA-D"],
    link: ""
  },
  sugarcane: {
    kicker: "RESEARCH · STATISTICS",
    title: "Sugarcane Yield & Production Risk",
    summary: "Research focused on predicting sugarcane yield and production risk in South Asia, with a focus on Pakistan.",
    bullets: ["Investigate rainfall, temperature, soil characteristics, and agricultural inputs as potential predictors.", "Planned methods include multiple linear regression and Random Forest.", "Add the final data sources, methodology, model evaluation, and findings when verified. Do not present proposed results as completed findings."],
    tags: ["Statistics", "Regression", "Random Forest", "Research"],
    link: ""
  },
  cafe: {
    kicker: "SQL · DATABASE ANALYSIS",
    title: "Girls Cafe Database",
    summary: "A cafe database project involving relational data, SQL queries, exploratory analysis, and data-mining techniques.",
    bullets: ["Show the database structure and selected SQL queries.", "Document the dataset, tables, and features actually included in the project.", "Add any association-analysis or classification results only after checking the original project."],
    tags: ["MySQL", "SQL", "Data Analysis"],
    link: ""
  },
  other: {
    kicker: "POWER BI · PROJECT PLACEHOLDER",
    title: "Additional Dashboard",
    summary: "This card is reserved for another Power BI dashboard you have created.",
    bullets: ["Replace this title with the real dashboard name.", "Add the dataset, business or research question, and key visuals.", "Upload a screenshot and include only verified findings."],
    tags: ["Power BI", "Add your dataset"],
    link: ""
  }
};
const modal = document.getElementById("modal");
const closeModal = () => { modal.classList.remove("open"); modal.setAttribute("aria-hidden","true"); document.body.style.overflow=""; };
document.querySelectorAll(".project-open").forEach(btn => btn.addEventListener("click", () => {
  const item = projectDetails[btn.dataset.open];
  if (!item) return;
  document.getElementById("modalKicker").textContent = item.kicker;
  document.getElementById("modalTitle").textContent = item.title;
  document.getElementById("modalSummary").textContent = item.summary;
  const bullets = document.getElementById("modalBullets");
  bullets.replaceChildren();
  item.bullets.forEach(text => { const li = document.createElement("li"); li.textContent = text; bullets.appendChild(li); });
  const tags = document.getElementById("modalTags");
  tags.replaceChildren();
  item.tags.forEach(text => { const span = document.createElement("span"); span.textContent = text; tags.appendChild(span); });
  const links = document.getElementById("modalLinks");
  if (item.link) { links.textContent = ""; const a = document.createElement("a"); a.href = item.link; a.textContent = "Open project ↗"; a.target = "_blank"; a.rel = "noopener"; a.className = "text-link"; links.appendChild(a); }
  else links.textContent = "Add your verified repository or demo link in projectDetails in script.js when available.";
  modal.classList.add("open"); modal.setAttribute("aria-hidden","false"); document.body.style.overflow="hidden";
}));
document.getElementById("modalClose").addEventListener("click", closeModal);
modal.addEventListener("click", e => { if (e.target === modal) closeModal(); });
document.addEventListener("keydown", e => { if (e.key === "Escape") closeModal(); });
document.querySelectorAll(".filter").forEach(btn => btn.addEventListener("click", () => {
  document.querySelectorAll(".filter").forEach(b => b.classList.remove("active"));
  btn.classList.add("active");
  document.querySelectorAll(".project-card").forEach(card => {
    card.classList.toggle("hidden", btn.dataset.filter !== "all" && card.dataset.category !== btn.dataset.filter);
  });
}));
const menuToggle = document.getElementById("menuToggle");
const nav = document.getElementById("nav");
menuToggle.addEventListener("click", () => { const open = nav.classList.toggle("open"); menuToggle.setAttribute("aria-expanded", String(open)); });
nav.querySelectorAll("a").forEach(a => a.addEventListener("click", () => { nav.classList.remove("open"); menuToggle.setAttribute("aria-expanded","false"); }));
document.getElementById("year").textContent = new Date().getFullYear();

// Replace these placeholders with your real public profile details before publishing.
const PROFILE = {
  email: "YOUR_EMAIL@example.com",
  github: "",
  linkedin: ""
};
document.getElementById("emailLink").href = "mailto:" + PROFILE.email;
for (const [id, url] of [["githubLink", PROFILE.github], ["linkedinLink", PROFILE.linkedin]]) {
  const el = document.getElementById(id);
  if (url) { el.href = url; } else { el.addEventListener("click", e => { e.preventDefault(); alert("Add your real profile URL in script.js before publishing."); }); }
}
