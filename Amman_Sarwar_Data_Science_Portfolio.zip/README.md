# Amman Sarwar — Data Science Portfolio

A responsive static portfolio website built with HTML, CSS, and vanilla JavaScript. It uses a dark navy/purple hero and light project pages, with project filters and detail modals.

## Preview locally
1. Extract the ZIP file.
2. Open `index.html` in a browser. For a more reliable local preview, use VS Code with the Live Server extension.
3. Replace placeholders in `script.js` (email, GitHub, LinkedIn).
4. Add your actual CV as `assets/Amman-Sarwar-CV.pdf` and add a CV download link in `index.html` when ready.
5. Replace mock project artwork with screenshots of your actual dashboards and app. The current artwork is illustrative and is not a screenshot of your work.

## Important accuracy notes
- The PBS dashboard, Jobs Dashboard, CREMA-D project, sugarcane research, and Girls Cafe database descriptions are based on details shared by the portfolio owner.
- Check the PBS internship dates and the current status of the GAO Tek internship before publishing.
- Add only verified project results, model metrics, dataset sources, repository URLs, and credentials.
- The "Additional Dashboard" card is intentionally a placeholder.

## Publish with GitHub Pages
1. Sign in to GitHub and create a new public repository, for example `amman-data-portfolio`.
2. Upload the contents of this folder (the files `index.html`, `styles.css`, `script.js`, and `assets/` must be at the repository root).
3. In the repository, open **Settings → Pages**.
4. Under build and deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
5. Wait for the Pages deployment to finish. GitHub will display the published URL in Settings → Pages.
6. Open the URL on your phone and laptop to check it.

## Alternative: Netlify
1. Sign in to Netlify.
2. Choose the option to deploy a site manually / deploy a folder.
3. Drag the extracted folder into the deployment area.
4. Netlify will provide a preview URL. You can set a custom domain later.

## Before sharing with recruiters
- Replace contact placeholders.
- Add a real CV PDF and a working download link.
- Add screenshots of the PBS and Jobs dashboards.
- Add the GitHub repository / code link for the voice emotion project if public.
- Test all links and mobile layout.
- Ensure any dataset can be shared publicly and does not contain private or restricted information.
